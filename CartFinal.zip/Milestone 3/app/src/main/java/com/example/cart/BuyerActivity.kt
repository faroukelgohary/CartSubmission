package com.example.cart

import android.app.ProgressDialog.show
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import com.example.cart.adapter.MyDrinkAdapter
import com.example.cart.eventbus.UpdateCartEvent
import com.example.cart.listener.ICartLoadListener
import com.example.cart.listener.IDrinkLoadListener
import com.example.cart.model.CartModel
import com.example.cart.model.DrinkModel
import com.example.cart.utils.SpaceItemDecoration
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.mainLayout
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import com.google.firebase.database.DatabaseReference
import com.google.firebase.auth.FirebaseAuth


class BuyerActivity : AppCompatActivity(), IDrinkLoadListener,ICartLoadListener {

    companion object {
        var passedString: String = ""
    }


    lateinit var drinkLoadListener: IDrinkLoadListener
    lateinit var cartLoadListener: ICartLoadListener

    private var user : String = ""
    val database = FirebaseDatabase.getInstance()
    val auth = FirebaseAuth.getInstance()


    override fun onStart() {
        super.onStart()
        EventBus.getDefault().register(this)
    }

    override fun onStop() {
        super.onStop()
        if (EventBus.getDefault().hasSubscriberForEvent(UpdateCartEvent::class.java))
            EventBus.getDefault().removeStickyEvent(UpdateCartEvent::class.java)
        EventBus.getDefault().unregister(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN, sticky = true)
     fun onUpdateCartEvent(event: UpdateCartEvent)
    {
        countCartFromFirebase()
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val myUser = auth.currentUser
        val email = myUser?.email.toString().split('@')[0]
//        val emailRef = database.getReference("user")
//        emailRef.setValue(email)

        init()

        passedString = intent.extras?.getString("sellerName").toString()

        // Function that takes the images from fire base
        loadDrinkFromFirebase()
        countCartFromFirebase()

    }

//    private fun countCartFromFirebase() {
//        val cartModels : MutableList<CartModel> = ArrayList()
//        FirebaseDatabase.getInstance()
//            .getReference("Products")
//            .child("FAROUK") // get from firebase authenticator
//            .addListenerForSingleValueEvent(object: ValueEventListener{
//                override fun onDataChange(snapshot: DataSnapshot) {
//                    for (cartSnapshot in snapshot.children)
//                    {
//                        val cartModel = cartSnapshot.getValue(CartModel::class.java)
//                        cartModel!!.name = cartSnapshot.key
//                        cartModels.add(cartModel)
//                    }
//                    cartLoadListener.onLoadCartSuccess(cartModels)
//                }
//
//                override fun onCancelled(error: DatabaseError) {
//                    cartLoadListener.onLoadCartFailed(error.message)
//                }
//
//            })
//    }

    private fun countCartFromFirebase() {
        val cartModels : MutableList<CartModel> = ArrayList()
        val seller = intent.extras?.getString("sellerName")
        FirebaseDatabase.getInstance()
            .getReference("Carts")
            .child(FirebaseAuth.getInstance().currentUser!!.email!!.split("@")[0])
            .child(seller!!)
            .addListenerForSingleValueEvent(object: ValueEventListener{
                override fun onDataChange(snapshot: DataSnapshot) {
                    for (cartSnapshot in snapshot.children)
                    {
                        val cartModel = cartSnapshot.getValue(CartModel::class.java)
                        cartModel!!.name = cartSnapshot.key
                        cartModels.add(cartModel)
                    }
                    cartLoadListener.onLoadCartSuccess(cartModels)
                }

                override fun onCancelled(error: DatabaseError) {
                    cartLoadListener.onLoadCartFailed(error.message)
                }

            })
    }


//    private fun loadDrinkFromFirebase() {
//        val drinkModels : MutableList<DrinkModel> = ArrayList()
//        FirebaseDatabase.getInstance().getReference("$user").child("Products").addListenerForSingleValueEvent(object : ValueEventListener{
//            override fun onDataChange(snapshot: DataSnapshot) {
//               if(snapshot.exists())
//               {
//                   for(drinkSnapshot in snapshot.children){
//                       //getting from firebase as product
//                       val product = drinkSnapshot.getValue(Product::class.java)
//                       product!!.name = drinkSnapshot.key!!
//                       //making a drinkModel from the product
//                       val drinkModel = DrinkModel()
//                       drinkModel.name = product.name
//                       drinkModel.image = product.image
//                       drinkModel.price = product.price.toString()
//                       drinkModels.add(drinkModel)
//                   }
//                   drinkLoadListener.onDrinkLoadSuccess(drinkModels)
//               }
//                else{
//                    drinkLoadListener.onDrinkLoadFaild("Shop items do not exist!!")
//               }
//            }
//
//            override fun onCancelled(error: DatabaseError) {
//                drinkLoadListener.onDrinkLoadFaild(error.message)
//            }
//
//        })
//    }


    private fun loadDrinkFromFirebase() {
        val drinkModels: MutableList<DrinkModel> = ArrayList()
        val seller = intent.extras?.getString("sellerName")
        FirebaseDatabase.getInstance().getReference("Sellers").child(seller!!)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        for (drinkSnapshot in snapshot.children) {
                            // getting from firebase as product
                            val product = drinkSnapshot.getValue(Product::class.java)
                            product!!.name = drinkSnapshot.key!!
                            // making a drinkModel from the product
                            val drinkModel = DrinkModel()
                            drinkModel.name = product.name
                            drinkModel.image = product.image
                            drinkModel.price = product.price.toString()
                            drinkModels.add(drinkModel)
                        }
                        drinkLoadListener.onDrinkLoadSuccess(drinkModels)
                    } else {
                        drinkLoadListener.onDrinkLoadFaild("Shop items do not exist!!")
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    drinkLoadListener.onDrinkLoadFaild(error.message)
                }
            })
    }

    // This function initializes the UI elements and sets up the listeners for the buttons
    private fun init(){
        // Initialize the drinkLoadListener and cartLoadListener as the current activity
        drinkLoadListener = this
        cartLoadListener = this
        // Create a GridLayoutManager with 2 columns
        val gridLayoutManager = GridLayoutManager(this,2)
        // Set the layout manager for the recycler_drink view
        recycler_drink.layoutManager = gridLayoutManager
        // Add an item decoration for the recycler_drink view
        recycler_drink.addItemDecoration(SpaceItemDecoration())

        // Set a click listener for the btnCart button
        btnCart.setOnClickListener {
            // Start the CartActivity and pass the sellerName as an extra in the intent
            startActivity(Intent(this,CartActivity::class.java))
            val sellerName = intent.extras?.getString("sellerName")
            intent.putExtra("sellerName", sellerName)
        }

        // Set a click listener for the backBtn button
        backBtn!!.setOnClickListener {
            // Finish the current activity
            finish()
        }
    }


    override fun onDrinkLoadSuccess(drinkModelList: List<DrinkModel>?) {
        val adapter = MyDrinkAdapter(this,drinkModelList!!,cartLoadListener)
        recycler_drink.adapter = adapter

    }

    override fun onDrinkLoadFaild(message: String?) {
        Snackbar.make(mainLayout,message!!,Snackbar.LENGTH_LONG).show()
    }

    override fun onLoadCartSuccess(cartModelList: List<CartModel>) {
        var cartSum = 0
        for (cartModel in cartModelList!!) cartSum+= cartModel!!.quantity
        badge!!.setNumber(cartSum)
    }

    override fun onLoadCartFailed(message: String?) {
        Snackbar.make(mainLayout,message!!,Snackbar.LENGTH_LONG).show()
    }

}