package com.example.cart

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.Button
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.activity_location_upload.*

class LocationUploadActivity : AppCompatActivity() {

    // Declare variables for the email, latitude, and longitude EditText views
    private lateinit var latitudeEditText: EditText
    private lateinit var longitudeEditText: EditText

    // Declare a variable for the upload button
    private lateinit var uploadButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_location_upload)

        // Initialize the latitude, and longitude EditText views
        latitudeEditText = findViewById(R.id.latitude_edit_text)
        longitudeEditText = findViewById(R.id.longitude_edit_text)

        // Initialize the upload button
        uploadButton = findViewById(R.id.upload_button)

        // Set an OnClickListener on the upload button
        uploadButton.setOnClickListener {
            // Get the user's email from the Firebase Authenticator
            val user = FirebaseAuth.getInstance().currentUser
            val email = user?.email.toString().split('@')[0]

            // Get the latitude and longitude from the EditText views
            val latitude = latitudeEditText.text.toString().toDouble()
            val longitude = longitudeEditText.text.toString().toDouble()

            // Create a SellerLocation object with the email, latitude, and longitude
            val sellerLocation = SellerLocation(latitude, longitude)

            // Reference the database node for the seller's location data
            val sellerLocationsRef = FirebaseDatabase.getInstance().getReference("Locations")

            // Set the value of the seller's location data to the SellerLocation object
            sellerLocationsRef.child(email!!).setValue(sellerLocation)

            latitudeEditText.text.clear()
            longitudeEditText.text.clear()
            finish()
        }

        delete_location_button.setOnClickListener {
            // Get the user's email from the Firebase Authenticator
            val user = FirebaseAuth.getInstance().currentUser
            val email = user?.email.toString().split('@')[0]

            // Reference the "Locations" child node in the Firebase Realtime Database
            val locationsRef = FirebaseDatabase.getInstance().getReference("Locations")

            // Identify the location node that you want to delete
            val myLocationRef = locationsRef.child(email)

            // Delete the location node
            myLocationRef.removeValue()
        }
    }
}

// Define a data class for the seller location data
data class SellerLocation(val latitude: Double, val longitude: Double)
