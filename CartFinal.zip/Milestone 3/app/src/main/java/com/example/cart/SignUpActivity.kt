package com.example.cart

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import android.view.KeyEvent
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.ActionBar
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_sign_up.*

class SignUpActivity : AppCompatActivity() {
    // ViewBinding
//    private lateinit var binding: ActivitySignUpBinding

    // ActionBar
    private lateinit var actionBar: ActionBar

    // ProgressDialog
    private lateinit var progressDialog: ProgressDialog

    // FirebaseAuth
    private lateinit var firebaseAuth: FirebaseAuth
    private var email = ""
    private var password = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_sign_up)

//        //Configure Actionbar
//        actionBar = supportActionBar!!
//        actionBar.title = "Sign Up"
//        actionBar.setDisplayHomeAsUpEnabled(false)
//        actionBar.setDisplayShowHomeEnabled(true)

        //configure progress dialog
        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Please wait")
        progressDialog.setMessage("Creating your account...")
        progressDialog.setCanceledOnTouchOutside(false)

        //intialize firebaseAuth
        firebaseAuth = FirebaseAuth.getInstance()

        //handle click, begin signup
        signUpBtn.setOnClickListener {
            //validate data
            validateData()
        }

        //handle enter key, begin sign in
        passwordEt.setOnClickListener {
            myEnter()
        }

        //handle click, sign in instead
        AccountTv.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

    }

    private fun myEnter() {
        passwordEt.setOnKeyListener(View.OnKeyListener { v, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_UP) {
                validateData()
                return@OnKeyListener true
            }
            false
        })
    }

    private fun validateData() {
        //get data
        email = emailEt.text.toString().trim()
        password = passwordEt.text.toString().trim()

        //validate data
        if (TextUtils.isEmpty(email)) {
            //no email entered
            emailEt.error = "Please enter email"
        }
        else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            //invalid email format
            emailEt.error = "Invalid email format"
        }
        else if (TextUtils.isEmpty(password)){
            //no password entered
            passwordEt.error = "Please enter password"
        }
        else if (password.length < 6) {
            passwordEt.error = "Password must be at least 6 characters long"
        }
        else{
            //data is validated, continue sign up
            firebaseSignUp()
        }
    }

    private fun firebaseSignUp() {
        //show progress
        progressDialog.show()

        //create new account
        firebaseAuth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                //sign up success
                progressDialog.dismiss()

                //get current user
                val firebaseUser = firebaseAuth.currentUser
                val email = firebaseUser!!.email
                Toast.makeText(this, "Account created with email $email", Toast.LENGTH_SHORT).show()

                //open profile
                startActivity(Intent(this, ProfileActivity::class.java))
                finish()

            }
            .addOnFailureListener { e->
                //sign up failure
                progressDialog.dismiss()
                Toast.makeText(this, "Sign Up failed dure to ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    override fun onBackPressed() {}

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed() //go back to previous activity, when back button of actionbar clicked
        return super.onSupportNavigateUp()
    }
}