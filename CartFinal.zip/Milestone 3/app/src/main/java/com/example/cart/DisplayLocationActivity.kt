package com.example.cart

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import android.widget.Toast

import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.example.cart.databinding.ActivityDisplayLocationBinding
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.Marker
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class DisplayLocationActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityDisplayLocationBinding

    public lateinit var databaseRef: DatabaseReference


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDisplayLocationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        // Reference the database node that contains the seller locations
        databaseRef = Firebase.database.getReference("Locations")
        databaseRef.addValueEventListener(logListener)
    }

    val logListener = object : ValueEventListener {
        override fun onCancelled(error: DatabaseError) {
            Toast.makeText(
                applicationContext, "Could not read from database",
                Toast.LENGTH_LONG
            ).show()
        }

        @SuppressLint("LongLog Tag")
        override fun onDataChange(dataSnapshot: DataSnapshot) {
            if (dataSnapshot.exists()) {
                // Clear any existing markers from the map
                mMap.clear()

                // Iterate over the seller locations in the database
                for (sellerLocationSnapshot in dataSnapshot.children)
                {
                    // Get the seller location data from the snapshot
                    val locationlogging = sellerLocationSnapshot.getValue(LocationLogging::class.java)
                    val sellerLat = locationlogging?.Latitude
                    val sellerLong = locationlogging?.Longitude

                    // Get the seller's name from the snapshot key
                    val sellerName = sellerLocationSnapshot.key

                    // If the seller location data is not null, add a marker to the map for the seller's location
                    if (sellerLat != null && sellerLong != null) {
                        val sellerLoc = LatLng(sellerLat, sellerLong)
                        val markerOptions = MarkerOptions().position(sellerLoc).title(sellerName)
                        mMap.addMarker(markerOptions)
                        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(sellerLoc, 10f))
                        //Zoom level - 1: World, 5: Landmass/continent, 10: City, 15: Streets and 20: Buildings

                        Toast.makeText(
                            applicationContext, "Locations accessed from the database",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }

    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap.uiSettings.isZoomControlsEnabled = true

        // Set a custom InfoWindowAdapter to customize the appearance of the marker's info window
        mMap.setInfoWindowAdapter(object : GoogleMap.InfoWindowAdapter {
            override fun getInfoWindow(marker: Marker): View? {
                // Inflate the custom info window layout
                val v = LayoutInflater.from(this@DisplayLocationActivity)
                    .inflate(R.layout.custom_info_window, null)

                // Set the marker title and description
                val title = v.findViewById<TextView>(R.id.title)
                title.text = marker.title

                val snippet = v.findViewById<TextView>(R.id.snippet)
                snippet.text = marker.snippet

                // Return the custom info window view
                return v
            }

            override fun getInfoContents(marker: Marker): View? {
                // Return null to use the default info window frame
                return null
            }
        })
    }
}