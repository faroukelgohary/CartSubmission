package com.example.cart

import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList


class SellerFragment : Fragment() {

    private lateinit var adapter : MyAdapter
    private lateinit var recyclerView : RecyclerView
    private lateinit var productsArrayList : ArrayList<Product> //this is just for the adapter
    private lateinit var database: DatabaseReference
    private lateinit var storageReference : StorageReference

    lateinit var ImageUri : Uri
    var imageLink : String = ""
    lateinit var imageId : Array<Int>
    lateinit var title : Array<String>
    lateinit var quantity : Array<Int>
    lateinit var price : Array<Int>
    lateinit var ImageURl : Array<String>

    private var user : String? = ""

    lateinit var userTextView : TextView
    lateinit var newImageView : ImageView
    var pickedPhoto : Uri? = null
    var pickedBitmap : Bitmap? = null
    val REQUEST_CODE = 100

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
//        init()
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_fragment1, container, false)
//        init()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //getting the user's email to add items in HIS directory only
        userTextView = requireActivity().findViewById(R.id.emailTv)
        user = userTextView.text.toString().split('@')[0]  //Firebase paths must not contain '.', '#', '$', '[', or ']'
        database = FirebaseDatabase.getInstance().getReference("Sellers")
        productsArrayList = arrayListOf<Product>()

        //getting the products of the seller that he had listed, for some reason you have to add an item first to read all products there :(
        database.child("$user").addListenerForSingleValueEvent(object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                if(snapshot.exists())
                {
                    for(productSnapshot in snapshot.children){
                        //getting all products of the seller from firebase
                        val product = productSnapshot.getValue(Product::class.java)
                        product!!.name = productSnapshot.key!!
                        productsArrayList.add(product)
                    }
                }
                else{
                    Toast.makeText(activity, "Nothing yet in store !", Toast.LENGTH_LONG).show()
                }
            }
            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(activity, "Warning: $error", Toast.LENGTH_LONG).show()
            }
        })
        //recycler view creation
        val layoutManager = LinearLayoutManager(context)
        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = layoutManager
        recyclerView.setHasFixedSize(true)
        adapter = MyAdapter(requireActivity(),productsArrayList)
        recyclerView.adapter = adapter

        //when delete icon is clicked, remove the product from the array list, and from firebase
        adapter.setOnDeleteClickListener(object : MyAdapter.OnDeleteClickListener{
            override fun OnDeleteClick(position: Int) {
                val productName : String = productsArrayList[position].name
                database.child("$user").child(productName).removeValue()
                productsArrayList.removeAt(position)
                recyclerView.adapter = adapter
                Toast.makeText(activity, "$productName was removed successfully !" , Toast.LENGTH_LONG).show()
            }

        })
        //when the edit icon is clicked, ask the user to use the below form for editing
        adapter.setOnEditClickListener(object : MyAdapter.OnEditClickListener{
            override fun OnEditClick(position: Int) {
                Toast.makeText(activity, "Edit product in the form below ..." , Toast.LENGTH_LONG).show()
            }
        })

        //getting the ImageView, editTexts, and Button of the form for adding a new item
        val newTitle = view.findViewById<EditText>(R.id.newItemTitle)
        val newQuantity = view.findViewById<EditText>(R.id.newItemQuantity)
        val newPrice = view.findViewById<EditText>(R.id.newItemPrice)
        val newItemBtn = view.findViewById<Button>(R.id.addItemBtn)
        val editItemBtn = view.findViewById<Button>(R.id.editItemBtn)
        newImageView = view.findViewById<ImageView>(R.id.newItemImage)

        //when AddImage imageView is Clicked
        newImageView.setOnClickListener(){
            openGalleryForImage()
        }

        //when Add Item is clicked
        newItemBtn.setOnClickListener(){
            //getting the text values of the editTexts
            val newTitleText : String= newTitle.text.toString()
            val newQuantityText : String= newQuantity.text.toString()
            val newPriceText : String = newPrice.text.toString()
            if(newTitleText.isEmpty() || newQuantityText.isEmpty() || newPriceText.isEmpty() || newImageView.drawable == null)
            {
                //if form of New product is not yet completed
                Toast.makeText(activity,"Information Missing !",Toast.LENGTH_LONG).show()
            }
            else
            {
                //else, add product to the array list, and upload the new item to firebase
                val newProduct = Product(R.drawable.default_image, newTitleText, newQuantityText.toInt(), newPriceText.toInt(), imageLink)
                productsArrayList.add(newProduct)
                database.child("$user").child(newTitleText).setValue(newProduct)
                recyclerView.adapter = adapter
                Toast.makeText(activity, "$newTitleText was added successfully !" , Toast.LENGTH_LONG).show()
                //clear the input text in the editText fields, and dismiss the progress bar
                newTitle.text.clear()
                newQuantity.text.clear()
                newPrice.text.clear()
                newImageView.setImageURI(null)
                newImageView.setImageResource(R.drawable.image)
            }
        }
        //when Edit Item is clicked
        editItemBtn.setOnClickListener(){
            val editName : String = newTitle.text.toString()
            val editQuantity : String = newQuantity.text.toString()
            val editPrice : String = newPrice.text.toString()
            //check if they are not empty first
            if(editName.isEmpty() || editQuantity.isEmpty() || editPrice.isEmpty())
            {
                //if form of the product is not yet completed
                Toast.makeText(activity,"Information Missing !",Toast.LENGTH_LONG).show()
            }
            else
            {
                //search for the Item with it's Product Name to be edited
                var found : Boolean = false
                for(i in productsArrayList)
                {
                    if(editName.uppercase().equals(i.name.uppercase()))
                    {
                        i.quantity = editQuantity.toInt()
                        i.price = editPrice.toInt()
                        database.child("$user").child(i.name).setValue(i)
                        found = true
                        recyclerView.adapter = adapter
                        Toast.makeText(activity,"Product Details Updated Successfully!",Toast.LENGTH_LONG).show()
                    }
                }
                if(!found)
                {
                    Toast.makeText(activity,"Item Not Found !!",Toast.LENGTH_LONG).show()
                }
            }
            //clear the input text in the editText fields
            newTitle.text.clear()
            newQuantity.text.clear()
            newPrice.text.clear()
        }
    }

    private fun dataInitialize(){
        productsArrayList = arrayListOf<Product>()
        database.child("$user").addListenerForSingleValueEvent(object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                if(snapshot.exists())
                {
                    for(productSnapshot in snapshot.children){
                        //getting all products of the seller from firebase
                        val product = productSnapshot.getValue(Product::class.java)
                        product!!.name = productSnapshot.key!!
                        productsArrayList.add(product)
                    }
                }
                else{
                    Toast.makeText(activity, "Nothing yet in store !", Toast.LENGTH_LONG).show()
                }
            }
            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(activity, "Warning: $error", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun init() {

        //getting the user's email to add items in HIS directory only
        userTextView = requireActivity().findViewById(R.id.emailTv)
        user = userTextView.text.toString().split('@')[0]  //Firebase paths must not contain '.', '#', '$', '[', or ']'
        database = FirebaseDatabase.getInstance().getReference("Sellers")
        productsArrayList = arrayListOf<Product>()

        //getting the products of the seller that he had listed, for some reason you have to add an item first to read all products there :(
        database.child("$user").addListenerForSingleValueEvent(object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                if(snapshot.exists())
                {
                    for(productSnapshot in snapshot.children){
                        //getting all products of the seller from firebase
                        val product = productSnapshot.getValue(Product::class.java)
                        product!!.name = productSnapshot.key!!
                        productsArrayList.add(product)
                    }
                }
                else{
                    Toast.makeText(activity, "Nothing yet in store !", Toast.LENGTH_LONG).show()
                }
            }
            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(activity, "Warning: $error", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun openGalleryForImage() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, REQUEST_CODE)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && requestCode == REQUEST_CODE){
            ImageUri = data?.data!!
            newImageView.setImageURI(ImageUri) // handle chosen image

        }
        // adding image to firebase storage
        val progressDialog = ProgressDialog(activity)
        progressDialog.setMessage("Uploading File ...")
        progressDialog.setCancelable(false)
        progressDialog.show()
        val formatter = SimpleDateFormat("yyyy_MM_dd_HH_mm_ss", Locale.getDefault())
        val now = Date()
        val fileName = formatter.format(now)
        storageReference = FirebaseStorage.getInstance().getReference("images/$fileName")
        storageReference.putFile(ImageUri).
        addOnSuccessListener {
            //getting the image URL
            val result = it.metadata!!.reference!!.downloadUrl;
            result.addOnSuccessListener {
                imageLink = it.toString()
            }
            if (progressDialog.isShowing) progressDialog.dismiss()
            Toast.makeText(activity, "Image Successfully Uploaded", Toast.LENGTH_SHORT).show()

        }.addOnFailureListener{
            if (progressDialog.isShowing) progressDialog.dismiss()
            Toast.makeText(activity,"Image Upload Failed", Toast.LENGTH_SHORT).show()
        }
    }

}