package com.example.cart.adapter

import android.content.Context
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.cart.BuyerActivity
import com.example.cart.BuyerActivity.Companion.passedString
import com.example.cart.Product
import com.example.cart.R
import com.example.cart.eventbus.UpdateCartEvent
import com.example.cart.listener.ICartLoadListener
import com.example.cart.listener.IRecyclerClickListener
import com.example.cart.model.CartModel
import com.example.cart.model.DrinkModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import org.greenrobot.eventbus.EventBus

class MyDrinkAdapter(
    private val contect: Context,
    private val list: List<DrinkModel>,
    private val cartListener: ICartLoadListener,




):RecyclerView.Adapter<MyDrinkAdapter.MyDrinkViewHolder>() {

    class MyDrinkViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView),
        View.OnClickListener {
         var imageView: ImageView?=null
         var txtName:TextView?=null
         var txtPrice:TextView?=null



        private var clickListener: IRecyclerClickListener? = null

        fun setClickListener(clickListener: IRecyclerClickListener)
        {
            this.clickListener = clickListener;
        }

          init {
              imageView = itemView.findViewById(R.id.imageView) as ImageView

              txtName = itemView.findViewById(R.id.txtName) as TextView
              txtPrice = itemView.findViewById(R.id.txtPrice) as TextView

              itemView.setOnClickListener(this)


          }

        override fun onClick(p0: View?) {
            clickListener!!.onItemClickListener(p0, adapterPosition)
        }


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyDrinkViewHolder {
        return MyDrinkViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.layout_drink_item,parent,false))
    }

    override fun onBindViewHolder(holder: MyDrinkViewHolder, position: Int) {
        Glide.with(contect).load(list[position].image).into(holder.imageView!!)
        holder.txtName!!.text = StringBuilder().append(list[position].name)
        holder.txtPrice!!.text = StringBuilder().append(list[position].price)

        holder.setClickListener(object:IRecyclerClickListener{
            override fun onItemClickListener(view: View?, position: Int) {

                val currentUser = FirebaseAuth.getInstance().currentUser
                val email = currentUser?.email.toString().split('@')[0]
                val cartRef = FirebaseDatabase.getInstance().getReference("Carts").child(email).child(passedString)

                // Retrieve the item that is being added to the cart
                val item = list[position]

                    cartRef.addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            // Check if the cart is empty
                            if (snapshot.exists()) {
                                // Loop through each item in the cart
                                for (itemSnapshot in snapshot.children) {
                                    // Check if the item being added to the cart is already in the cart
                                    if (itemSnapshot.getValue(CartModel::class.java)?.name == item.name) {
                                        // Display a toast message to inform the user that they need to add more items to their cart
                                        Toast.makeText(contect, "Please add more items to your cart.", Toast.LENGTH_SHORT).show()
                                        return // return from the function to stop execution
                                    }
                                }
                            }
                            // If the item is not in the cart, add it to the cart
                            addToCart(item)
                        }

                        override fun onCancelled(error: DatabaseError) {
                            // Display a toast message to the user to inform them that the operation has been cancelled
                            Toast.makeText(contect, "Operation cancelled", Toast.LENGTH_SHORT).show()
                            // Log the error to help debug the issue
                            Log.e("ERROR", "Database operation cancelled: ${error.message}")
                        }
                    })

//                val cartRef = FirebaseDatabase.getInstance().getReference("Carts")
//
//                // Get current user's email
//                val currentUser = FirebaseAuth.getInstance().currentUser
//                val email = currentUser?.email.toString().split('@')[0]
//
////                addToCart(list[position])
////                Toast.makeText(contect, "${cartRef.child(email).child(BuyerActivity.passedString)}", Toast.LENGTH_SHORT).show()
//
//                // Get reference to the current item in the user's cart
//                cartRef.child(email).child(BuyerActivity.passedString)
//                    .addListenerForSingleValueEvent(object : ValueEventListener {
//                        override fun onDataChange(snapshot: DataSnapshot) {
//                            val check = snapshot.exists()
//                            if (snapshot.exists()) {
//                                for (itemSnapshot in snapshot.children) {
//                                    if (snapshot.exists()) {
//
//                                        // Decrement the quantity of the item in the seller's cart by the quantity in the user's cart
//                                        val userProduct =
//                                            itemSnapshot.getValue(CartModel::class.java)
//                                        val itemName = userProduct?.name.toString()
//
//                                        val shopProduct: DrinkModel = list[position]
//                                        val shopProductName = shopProduct.name
//
//                                        Toast.makeText(contect, "$shopProductName", Toast.LENGTH_SHORT).show()
//
//
//                                        if (itemName.equals(shopProductName)) {
//                                            // do nothing
//                                            val toastt = Toast.makeText(contect, "Add more items in the cart", Toast.LENGTH_SHORT)
//                                            toastt.setGravity(Gravity.TOP, 0, 0)
//                                            toastt.show()
//                                        } else {
//                                            Toast.makeText(contect, "TESTTT", Toast.LENGTH_SHORT)
//                                                .show()
//
//                                            addToCart(list[position])
//                                        }
//
//                                    } else {
////                                        // do thing
////                                        val toast = Toast.makeText(contect, "ELSE", Toast.LENGTH_SHORT)
////                                        toast.setGravity(Gravity.TOP, 0, 0)
////                                        toast.show()
////
////                                        addToCart(list[position])
//                                    }
//                                }
//                            }
//                            else {
//                                // do thing
//                                val toasttt = Toast.makeText(contect, "BIG ELSE", Toast.LENGTH_SHORT)
//                                toasttt.setGravity(Gravity.CENTER, 0, 0)
//                                toasttt.show()
//
//                                addToCart(list[position])
//                            }
//
//
//                        }
//
//                        override fun onCancelled(error: DatabaseError) {
//                            // Display a toast message to the user to inform them that the operation has been cancelled
//                            Toast.makeText(contect, "Operation cancelled", Toast.LENGTH_SHORT).show()
//                            // Log the error to help debug the issue
//                            Log.e("ERROR", "Database operation cancelled: ${error.message}")
//                        }
//
//                    })
            }

        })




    }

    private fun addToCart(drinkModel: DrinkModel) {

        val user = FirebaseAuth.getInstance().currentUser
        val email = user?.email.toString().split('@')[0]
        val passedString = BuyerActivity.passedString
//        val toast = Toast.makeText(contect,passedString,Toast.LENGTH_LONG)
//        toast.setGravity(Gravity.TOP, 0, 0)
//        toast.show()



        val userCart = FirebaseDatabase.getInstance()
            .getReference("Carts")
            .child(email)
            .child(passedString)
            userCart.child(drinkModel.name!!)
                .addListenerForSingleValueEvent(object: ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        if (snapshot.exists()) // if item is already in the cart, just update
                        {

                            val cartModel = snapshot.getValue(CartModel::class.java)
                            val updateData: MutableMap<String, Any> = HashMap()

                            cartModel!!.quantity = cartModel!!.quantity+1;
                            updateData["quantity"] = cartModel!!.quantity
                            updateData["totalPrice"] = cartModel!!.quantity * cartModel.price!!.toFloat()

                            userCart.child(drinkModel.name!!)
                                .updateChildren(updateData)
                                .addOnSuccessListener {
                                    EventBus.getDefault().postSticky(UpdateCartEvent())
                                    cartListener.onLoadCartFailed("Success add to cart")
                                }
                                .addOnFailureListener{e-> cartListener.onLoadCartFailed(e.message)}
                        }
                        else // if item is not in the cart, then add new
                        {
                            val cartModel = CartModel()
                            cartModel.name = drinkModel.name
                            cartModel.image = drinkModel.image
                            cartModel.price = drinkModel.price
                            cartModel.quantity = 1
                            cartModel.totalPrice = drinkModel.price!!.toFloat()


                            userCart.child(drinkModel.name!!)
                                .setValue(cartModel)
                                .addOnSuccessListener {
                                EventBus.getDefault().postSticky(UpdateCartEvent())
                                    cartListener.onLoadCartFailed("Success add to cart")
                                }
                                .addOnFailureListener { e-> cartListener.onLoadCartFailed(e.message) }
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        cartListener.onLoadCartFailed(error.message)
                    }
                })



    }

    override fun getItemCount(): Int {
        return list.size
    }

}


