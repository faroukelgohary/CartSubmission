package com.example.cart.adapter

import android.app.AlertDialog
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.cart.BuyerActivity.Companion.passedString
import com.example.cart.Product
import com.example.cart.R
import com.example.cart.eventbus.UpdateCartEvent
import com.example.cart.model.CartModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import org.greenrobot.eventbus.EventBus

class MyCartAdapter(
    private val context: Context,
    private val cartModelList: List<CartModel>
): RecyclerView.Adapter<MyCartAdapter.MyCartViewHolder>() {



    class MyCartViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        var btnMinus: ImageView?= null
        var btnPlus: ImageView?= null
        var imageView: ImageView?= null
        var btnDelete: ImageView?= null


        var txtName: TextView?= null
        var txtPrice: TextView?= null
        var txtQuantity: TextView?= null

        init {
            btnMinus = itemView.findViewById(R.id.btnMinus) as ImageView
            btnPlus = itemView.findViewById(R.id.btnPlus) as ImageView
            btnDelete = itemView.findViewById(R.id.btnDelete) as ImageView
            imageView = itemView.findViewById(R.id.imageView) as ImageView

            txtName = itemView.findViewById(R.id.txtName) as TextView
            txtPrice = itemView.findViewById(R.id.txtPrice) as TextView
            txtQuantity = itemView.findViewById(R.id.txtQuantity) as TextView
        }



    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyCartViewHolder {
        return MyCartViewHolder(
            LayoutInflater.from(context)
            .inflate(R.layout.layout_cart_item,parent,false))
    }

    override fun onBindViewHolder(holder: MyCartViewHolder, position: Int) {
        Glide.with(context)
            .load(cartModelList[position].image)
            .into(holder.imageView!!)

        holder.txtName!!.text = StringBuilder().append(cartModelList[position].name)
        holder.txtPrice!!.text = StringBuilder("EGP ").append(cartModelList[position].price)
        holder.txtQuantity!!.text = StringBuilder("").append(cartModelList[position].quantity)

        //handle click, Minus
        holder.btnMinus!!.setOnClickListener{_ -> minusCartItem(holder, cartModelList[position])}

        //handle click, Plus
        holder.btnPlus!!.setOnClickListener{_ -> plusCartItem(holder, cartModelList[position])}

        //handle click, Delete
        holder.btnDelete!!.setOnClickListener { _ ->
            val dialog = AlertDialog.Builder(context)
                .setTitle("Delete Item")
                .setMessage("Do you really want to delete this item")
                .setNegativeButton("CANCEL") { dialog, _ -> dialog.dismiss() }
                .setPositiveButton("DELETE") { dialog, _ ->
                    notifyItemRemoved(position)

                    val user = FirebaseAuth.getInstance().currentUser
                    val email = user?.email.toString().split('@')[0]

                    FirebaseDatabase.getInstance()
                        .getReference("Carts")
                        .child(email)
                        .child(passedString)
                        .child(cartModelList[position].name!!)
                        .removeValue()
                        .addOnSuccessListener {
                            EventBus.getDefault().postSticky(UpdateCartEvent())
                        }
                }
                .create()
            dialog.show()
        }

    }

    private fun plusCartItem(holder: MyCartAdapter.MyCartViewHolder, cartModel: CartModel) {
        // Get current user's email
        val currentUser = FirebaseAuth.getInstance().currentUser
        val email = currentUser?.email.toString().split('@')[0]

        // Get reference to the "Sellers" and "Carts" nodes in the database
        val sellerRef = FirebaseDatabase.getInstance().getReference("Sellers")
        val cartRef = FirebaseDatabase.getInstance().getReference("Carts")

        // Get reference to the current item in the user's cart
        cartRef.child(email).child(passedString)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    for (itemSnapshot in snapshot.children) {
                        if (snapshot.exists()) {
                            // Get values for the item in the user's cart
                            val userProduct = itemSnapshot.getValue(CartModel::class.java)
                            val itemName = userProduct?.name.toString()
                            val userQuantity = userProduct?.quantity.toString()

                            // Get reference to the seller's products
                            val stockQuantitySnapshot = sellerRef.child(passedString)

                            // Add a ValueEventListener to listen for changes in the data
                            stockQuantitySnapshot.addListenerForSingleValueEvent(object : ValueEventListener {
                                override fun onDataChange(snapshot: DataSnapshot) {
                                    for (productSnapshot in snapshot.children) {
                                        // Get values for the product in the seller's products
                                        var stockProduct = productSnapshot.getValue(Product::class.java)
                                        var stockName = stockProduct?.name.toString()

                                        // If the names of the item in the user's cart and the product in the seller's products match
                                        if (itemName.equals(stockName)) {
                                            var stockQuantity = stockProduct?.quantity?.toInt()

                                            // If the quantity of the item in the user's cart is less than the quantity of the product in the seller's products
                                            if (userQuantity.toInt() < stockQuantity!!) {
                                                // Increment the quantity of the item in the user's cart by 1
                                                cartModel.quantity += 1
                                                // Update the total price of the item
                                                cartModel.totalPrice =
                                                    cartModel.quantity * cartModel.price!!.toFloat()

                                                // Update the quantity and total price in the Firebase Database
                                                updateFirebase(cartModel)
                                            }
                                        }
                                    }
                                }
                                override fun onCancelled(error: DatabaseError) {
//                                    // Handle the error here
                                }
                            })
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }
            })


//        // Get current user's email
//        val currentUser = FirebaseAuth.getInstance().currentUser
//        val email = currentUser?.email.toString().split('@')[0]
//
//        // Get reference to the "Sellers" and "Carts" nodes in the database
//        val sellerRef = FirebaseDatabase.getInstance().getReference("Sellers")
//        val cartRef = FirebaseDatabase.getInstance().getReference("Carts")
//
//
//        // Get reference to the current item in the user's cart
//        cartRef.child(email).child(passedString)
//            .addListenerForSingleValueEvent(object : ValueEventListener {
//                override fun onDataChange(snapshot: DataSnapshot) {
//                    for (itemSnapshot in snapshot.children) {
////                        var itemName = itemSnapshot.value.toString()
////                        Toast.makeText(applicationContext,itemName,Toast.LENGTH_LONG).show()
//
//                        if (snapshot.exists()) {
//                            // Decrement the quantity of the item in the seller's cart by the quantity in the user's cart
//                            val userProduct = itemSnapshot.getValue(CartModel::class.java)
//                            val itemName = userProduct?.name.toString()
//                            val userQuantity = userProduct?.quantity.toString()
//
//                            val stockQuantitySnapshot = sellerRef.child(passedString)
//
//                            stockQuantitySnapshot.addListenerForSingleValueEvent(object : ValueEventListener {
//                                override fun onDataChange(snapshot: DataSnapshot) {
//                                    for (productSnapshot in snapshot.children) {
//                                        var stockProduct = productSnapshot.getValue(Product::class.java)
//                                        var stockName = stockProduct?.name.toString()
//
//
//                                        if (itemName.equals(stockName)) {
////                                            Toast.makeText(applicationContext,"TEST",Toast.LENGTH_LONG).show()
//                                            var stockQuantity = stockProduct?.quantity?.toInt()
//
//                                            if (userQuantity.toInt() < stockQuantity!!){
//                                                cartModel.quantity += 1
//                                                cartModel.totalPrice = cartModel.quantity * cartModel.price!!.toFloat()
//
//                                                holder.txtQuantity!!.text = StringBuilder("").append(cartModel.quantity)
//                                                updateFirebase(cartModel)
//                                            }
//                                        }
//                                        else {
//                                            // do nothing
//                                            Toast.makeText(context, "Reached maximum quantity", Toast.LENGTH_SHORT).show()
//
//                                        }
//                                    }
//                                }
//
//                                override fun onCancelled(error: DatabaseError) {
//                                    // Handle the error here
//                                }
//                            })
//
//
//
//                        }
//                    }
//
//                }
//
//                override fun onCancelled(error: DatabaseError) {
//                    // Display a toast message to the user to inform them that the operation has been cancelled
//                    Toast.makeText(context, "Operation cancelled", Toast.LENGTH_SHORT).show()
//                    // Log the error to help debug the issue
//                    Log.e("ERROR", "Database operation cancelled: ${error.message}")
//                }
//
//            })



    }

    private fun minusCartItem(holder: MyCartAdapter.MyCartViewHolder, cartModel: CartModel) {
        if (cartModel.quantity > 1)
        {
            cartModel.quantity -= 1
            cartModel.totalPrice = cartModel.quantity * cartModel.price!!.toFloat()

            holder.txtQuantity!!.text = StringBuilder("").append(cartModel.quantity)
            updateFirebase(cartModel)

        }
    }

//    private fun updateFirebase(cartModel: CartModel) {
//        FirebaseDatabase.getInstance()
//            .getReference("Cart")
//            .child("FAROUK") //get from firebase authenticator
//            .child(cartModel.name!!)     // was missing ---------------
//            .setValue(cartModel)
//            .addOnSuccessListener { EventBus.getDefault().postSticky(UpdateCartEvent()) }
//
//    }

    private fun updateFirebase(cartModel: CartModel) {
        val user = FirebaseAuth.getInstance().currentUser
        val email = user?.email.toString().split('@')[0]

        FirebaseDatabase.getInstance()
            .getReference("Carts")
            .child(email)
            .child(passedString)
            .child(cartModel.name!!)
            .setValue(cartModel)
            .addOnSuccessListener { EventBus.getDefault().postSticky(UpdateCartEvent()) }
    }


    override fun getItemCount(): Int {
        return cartModelList.size
    }
}