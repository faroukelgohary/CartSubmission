package com.example.cart.eventbus

class UpdateCartEvent {
}