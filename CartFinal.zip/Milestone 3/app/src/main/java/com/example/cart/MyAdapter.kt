package com.example.cart

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.view.menu.MenuView.ItemView
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class MyAdapter(private val context: FragmentActivity, private val productList : ArrayList<Product>) : RecyclerView.Adapter<MyAdapter.MyViewHolder>() {

    private lateinit var deleteListener : OnDeleteClickListener
    private lateinit var editListener : OnEditClickListener

    interface OnDeleteClickListener{
        fun OnDeleteClick(position: Int)
    }

    interface OnEditClickListener{
        fun OnEditClick(position: Int)
    }

    fun setOnDeleteClickListener(listener : OnDeleteClickListener){
        deleteListener = listener
    }

    fun setOnEditClickListener(listener : OnEditClickListener){
        editListener = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.list_item, parent, false)
        return MyViewHolder(itemView, deleteListener, editListener)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        val currentItem = productList[position]
        //holder.myImg.setImageResource(currentItem.titleImage)
        Glide.with(context).load(currentItem.image).into(holder.myImg!!)
        holder.myTitle.text = currentItem.name
        holder.myQuantity.text = "Quantity: " + currentItem.quantity.toString()
        holder.myPrice.text = "Price: " + currentItem.price.toString() + "$"

    }

    override fun getItemCount(): Int {
        return productList.size
    }

    class MyViewHolder(itemView: View, deleteListener : OnDeleteClickListener, editListener : OnEditClickListener) : RecyclerView.ViewHolder(itemView) {
        val myImg: ImageView = itemView.findViewById(R.id.imgView)
        val myTitle: TextView = itemView.findViewById(R.id.titleTv)
        val myQuantity: TextView = itemView.findViewById(R.id.quantityTv)
        val myPrice: TextView = itemView.findViewById(R.id.priceTv)

        val myEditBtn : Button = itemView.findViewById(R.id.editBtn)
        val myDeleteBtn : Button = itemView.findViewById(R.id.deleteBtn)

        init {
            myDeleteBtn.setOnClickListener {
                deleteListener.OnDeleteClick(adapterPosition)
            }
            myEditBtn.setOnClickListener {
                editListener.OnEditClick(adapterPosition)
            }
        }

    }
}