package com.example.cart.listener

import com.example.cart.model.DrinkModel

interface IDrinkLoadListener {
    // first step
    fun onDrinkLoadSuccess(drinkModelList: List<DrinkModel>?)
    fun onDrinkLoadFaild(message:String?)

}