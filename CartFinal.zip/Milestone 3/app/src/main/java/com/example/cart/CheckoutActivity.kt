package com.example.cart


import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import android.annotation.SuppressLint
import android.view.Gravity
import com.example.cart.BuyerActivity.Companion.passedString
import com.example.cart.model.CartModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.android.synthetic.main.activity_checkout.*

class CheckoutActivity : AppCompatActivity() {

    private var itemsCost: Int = 0
    private var deliveryCost: Double? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout)

        //        val itemsCost = intent.getStringExtra("TotalPrice")

        // Retrieve the sum variable from the intent
        itemsCost = intent.getDoubleExtra("ItemsCost", 0.0).toInt()

        // display the items cost
        txtItemsCost.text = itemsCost.toString()

        calculateDeliveryCost()



        // set onClickListener for the order button
        btnOrder.setOnClickListener {
            completeOrder()
        }
    }

    private fun completeOrder() {
        // Get current user's email
        val currentUser = FirebaseAuth.getInstance().currentUser
        val email = currentUser?.email.toString().split('@')[0]

        // Get reference to the "Sellers" and "Carts" nodes in the database
        val sellerRef = FirebaseDatabase.getInstance().getReference("Sellers")
        val cartRef = FirebaseDatabase.getInstance().getReference("Carts")

        val databaseRef = FirebaseDatabase.getInstance().getReference()



//        // Get reference to the items in the seller's products
//        sellerRef.child(passedString)
//            .addListenerForSingleValueEvent(object : ValueEventListener {
//                override fun onDataChange(snapshot: DataSnapshot) {
//                    // Iterate through each item in the seller's items
//                    for (itemSnapshot in snapshot.children) {
//                        val itemName = itemSnapshot.child("name").value as String
//                        val test = Toast.makeText(applicationContext,"testtt",Toast.LENGTH_LONG)
//                        test.setGravity(Gravity.TOP, 0, 0)
//                        test.show()












        // Get reference to the current item in the user's cart
        cartRef.child(email).child(passedString)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    for (itemSnapshot in snapshot.children) {
//                        var itemName = itemSnapshot.value.toString()
//                        Toast.makeText(applicationContext,itemName,Toast.LENGTH_LONG).show()

                        if (snapshot.exists()) {
                            // Decrement the quantity of the item in the seller's cart by the quantity in the user's cart
                            val userProduct = itemSnapshot.getValue(CartModel::class.java)
                            val itemName = userProduct?.name.toString()
                            val userQuantity = userProduct?.quantity.toString()

                            val stockQuantitySnapshot = sellerRef.child(passedString)

                            stockQuantitySnapshot.addListenerForSingleValueEvent(object : ValueEventListener {
                                override fun onDataChange(snapshot: DataSnapshot) {
                                    for (productSnapshot in snapshot.children) {
                                        var stockProduct = productSnapshot.getValue(Product::class.java)
                                        var stockName = stockProduct?.name.toString()


                                        if (itemName.equals(stockName)) {
//                                            Toast.makeText(applicationContext,"TEST",Toast.LENGTH_LONG).show()
                                            var stockQuantity = stockProduct?.quantity?.toInt()

                                            Toast.makeText(applicationContext,"$stockQuantity",Toast.LENGTH_LONG).show()
                                            var newQuantity = stockQuantity?.minus(userQuantity.toInt()!!)
                                            stockProduct!!.quantity = newQuantity!!

                                            if (newQuantity != null) {
                                                if (newQuantity > 0) {
                                                    sellerRef.child(passedString)
                                                            .child(itemName!!).setValue(stockProduct)
                                                    // Remove the cart from the user's "Carts" node
                                                    cartRef.child(email).child(passedString).removeValue()
                                                } else {
                                                    stockProduct!!.quantity = 0
                                                    sellerRef.child(passedString).child(itemName!!).setValue(stockProduct)
                                                    // Remove the cart from the user's "Carts" node
                                                    cartRef.child(email).child(passedString).removeValue()
                                                }
                                            }

                                        }
                                    }
                                }

                                override fun onCancelled(error: DatabaseError) {
                                    // Handle the error here
                                }
                            })



                        }
                    }

                }

                override fun onCancelled(error: DatabaseError) {
                    // Display a toast message to the user to inform them that the operation has been cancelled
                    Toast.makeText(applicationContext, "Operation cancelled", Toast.LENGTH_SHORT).show()
                    // Log the error to help debug the issue
                    Log.e("ERROR", "Database operation cancelled: ${error.message}")
                }

            })



//                    }
//                }

//                override fun onCancelled(error: DatabaseError) {
//                    // Display a toast message to the user to inform them that the operation has been cancelled
//                    Toast.makeText(applicationContext, "Operation cancelled", Toast.LENGTH_SHORT).show()
//                    // Log the error to help debug the issue
//                    Log.e("ERROR", "Database operation cancelled: ${error.message}")
//                }
//
//            })



        // Show a toast message and navigate to the ProfileActivity
        Toast.makeText(this, "Order placed successfully", Toast.LENGTH_SHORT).show()
        startActivity(Intent(this, ProfileActivity::class.java))
    }

//
//        val currentUser = FirebaseAuth.getInstance().currentUser
//        val email = currentUser?.email.toString().split('@')[0]
//        val sellerRef = FirebaseDatabase.getInstance().getReference("Sellers")
//        sellerRef.child(passedString).child("Items")
//            .addListenerForSingleValueEvent(object : ValueEventListener {
//                override fun onDataChange(snapshot: DataSnapshot) {
//                    for (itemSnapshot in snapshot.children) {
//                        val item = itemSnapshot.getValue(CartModel::class.java)
//                        val cartRef = FirebaseDatabase.getInstance().getReference("Carts")
//                        cartRef.child(email).child(passedString).child(item?.name!!)
//                            .addListenerForSingleValueEvent(object : ValueEventListener {
//                                override fun onDataChange(snapshot: DataSnapshot) {
//                                    if (snapshot.exists()) {
//                                        val currentQuantity = snapshot.child("quantity").value as Long
//                                        val newQuantity = currentQuantity - item.quantity
//                                        if (newQuantity > 0) {
//                                            item.quantity = newQuantity
//                                            sellerRef.child(passedString).child("Items")
//                                                .child(itemSnapshot.key!!).setValue(item)
//                                        } else {
//                                            sellerRef.child(passedString).child("Items")
//                                                .child(itemSnapshot.key!!).removeValue()
//                                        }
//                                    }
//                                }
//
//                                override fun onCancelled(error: DatabaseError) {
//                                    // Do nothing
//                                }
//                            })
//                    }
//                }
//
//                override fun onCancelled(error: DatabaseError) {
//                    // Do nothing
//                }
//            })
//        val cartRef = FirebaseDatabase.getInstance().getReference("Carts")
//        cartRef.child(email).child(passedString).removeValue()
//        Toast.makeText(this, "Order placed successfully", Toast.LENGTH_SHORT).show()
//        startActivity(Intent(this, ProfileActivity::class.java))

    
    private fun calculateDeliveryCost() {
        val database = FirebaseDatabase.getInstance()
        val locationsRef = database.getReference("Locations").child(passedString)
        locationsRef.addValueEventListener(object: ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
//                val sellerLatitude = snapshot.child("latitude").value as Double
                val sellerLatitude = snapshot.child("latitude").value as Number
                val sellerLatitudeDouble = sellerLatitude.toDouble()

//                val sellerLongitude = snapshot.child("longitude").value as Double

                val sellerLongitude = snapshot.child("latitude").value as Number
                val sellerLongitudeDouble = sellerLatitude.toDouble()

                // Get current location
                val currentLatitude = getCurrentLatitude()
                val currentLongitude = getCurrentLongitude()

                // Calculate distance between current location and seller location
                val distance = calculateDistance(currentLatitude, currentLongitude, sellerLatitudeDouble, sellerLongitudeDouble)

                // Get the delivery cost
                deliveryCost = getDeliveryCost(distance)

                // Set delivery cost based on distance
                txtDeliveryCost.text = deliveryCost.toString()

                val totalCost = itemsCost.toDouble() + deliveryCost!!

                txtTotalCost.text = totalCost.toString()



            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }

    private fun getDeliveryCost(distance: Double): Double {
        return distance * 10
    }


    private fun calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
//        val earthRadius = 6371 // Radius of the earth in kilometers
//        val dLat = Math.toRadians(lat2 - lat1)
//        val dLon = Math.toRadians(lon2 - lon1)
//        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
//                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
//                Math.sin(dLon / 2) * Math.sin(dLon / 2)
//        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
//        val distance = earthRadius * c // Distance in kilometers

//        val dLat = Math.pow((lat2 - lat1), 2.0)
//        val dLon = Math.pow((lon2 - lon1), 2.0)
//
//        val distance = Math.sqrt((dLat+dLon))
        val theta = lon1 - lon2
        var dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta))
        dist = Math.acos(dist)
        dist = rad2deg(dist)
        dist = dist * 60 * 1.1515
        dist = dist * 1.609344
        val distance = dist

        return distance
    }

    private fun deg2rad(deg: Double): Double {
        return deg * Math.PI / 180.0
    }

    private fun rad2deg(rad: Double): Double {
        return rad * 180.0 / Math.PI
    }

//        return distance
//    }


    private fun getCurrentLatitude(): Double {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
            == PackageManager.PERMISSION_GRANTED) {
            val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val locationProvider = LocationManager.NETWORK_PROVIDER
            val currentLocation = locationManager.getLastKnownLocation(locationProvider)
            if (currentLocation != null) {
                return currentLocation.latitude
            }
        }
        return 0.0 // return 0.0 if permission is not granted
    }
    

    private fun getCurrentLongitude(): Double {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
            == PackageManager.PERMISSION_GRANTED) {
            val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val locationProvider = LocationManager.NETWORK_PROVIDER
            val currentLocation = locationManager.getLastKnownLocation(locationProvider)
            if (currentLocation != null) {
                return currentLocation.longitude
            }
        }
        return 0.0 // return 0.0 if permission is not granted
    }


}