package com.example.cart

data class Product(var titleImage : Int = 0, var name : String = "", var quantity : Int = 0, var price : Int = 0, var image : String = "")
