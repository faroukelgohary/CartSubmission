package com.example.cart

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class SelectSellerActivity : AppCompatActivity() {


    private lateinit var sellers: ArrayList<String>
    private lateinit var adapter: ArrayAdapter<String>

    private lateinit var productRef: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select_seller)

        val sellerSpinner: Spinner = findViewById(R.id.seller_spinner)
        val viewProductsButton: Button = findViewById(R.id.view_products_button)

        val user = FirebaseAuth.getInstance().currentUser
        val userEmail = user?.email.toString().split('@')[0]


        sellers = ArrayList()
        adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, sellers)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sellerSpinner.adapter = adapter

        //database = FirebaseDatabase.getInstance().getReference("Products")
        val productsRef = FirebaseDatabase.getInstance().getReference("Sellers")

        productsRef.addValueEventListener(object: ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                sellers.clear()
                for (snapshot in dataSnapshot.children) {
                    sellers.add(snapshot.key!!)
                }
                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
                // You can log the error or show an alert dialog to the user
                println("Error: ${error.message}")
            }
        })

        viewProductsButton.setOnClickListener {
            val sellerName = sellerSpinner.selectedItem.toString()
            val intent = Intent(this, BuyerActivity::class.java)
            intent.putExtra("sellerName", sellerName)
            startActivity(intent)
        }
    }
}
