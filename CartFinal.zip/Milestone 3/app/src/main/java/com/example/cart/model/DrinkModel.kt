package com.example.cart.model

class DrinkModel {
    //Second
//    var key:String?=null
    var name:String?=null
    var image:String?=null
    var price:String?=null

}