package com.example.cart

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class VOIPActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_voip_main)

        findViewById<Button>(R.id.videoBtn).setOnClickListener {
            val intent = Intent(this, Video::class.java)
            startActivity(intent)
        }

        findViewById<Button>(R.id.voiceBtn).setOnClickListener {
            val intent = Intent(this, Voice::class.java)
            startActivity(intent)
        }
    }
}