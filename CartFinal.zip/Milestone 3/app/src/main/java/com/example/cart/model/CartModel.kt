package com.example.cart.model

class CartModel {
//    var key:String?= null
    var name:String?=null
    var image:String?=null
    var price:String?=null
    var quantity = 0
    var totalPrice = 0f
}

